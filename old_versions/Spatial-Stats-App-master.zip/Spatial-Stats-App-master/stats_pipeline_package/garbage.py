import numpy as np
z = np.zeros(5)
print(z.shape)
x = [1,1,1]
z[0:3] = x
print(z)